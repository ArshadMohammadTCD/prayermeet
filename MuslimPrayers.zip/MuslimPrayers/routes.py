from flask import render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from app import app, db
from models import User, PrayerSession, SessionAttendee
from forms import LoginForm, RegisterForm, PrayerSessionForm
from datetime import datetime

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))

    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and user.check_password(form.password.data):
            login_user(user)
            return redirect(url_for('index'))
        flash('Invalid username or password')
    return render_template('auth/login.html', form=form)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))

    form = RegisterForm()
    if form.validate_on_submit():
        user = User(username=form.username.data, email=form.email.data)
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        flash('Registration successful!')
        return redirect(url_for('login'))
    return render_template('auth/register.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/prayers/create', methods=['GET', 'POST'])
@login_required
def create_prayer():
    form = PrayerSessionForm()
    if form.validate_on_submit():
        try:
            # Parse the formatted datetime string
            date_str = form.date_time.data
            date_time = datetime.strptime(date_str, '%B %d, %Y at %I:%M %p')

            session = PrayerSession(
                prayer_type=form.prayer_type.data,
                date_time=date_time,
                location_name=form.location_name.data,
                latitude=form.latitude.data,
                longitude=form.longitude.data,
                capacity=form.capacity.data,
                notes=form.notes.data,
                creator_id=current_user.id
            )
            db.session.add(session)
            db.session.commit()
            flash('Prayer session created successfully!')
            return redirect(url_for('view_prayers'))
        except ValueError as e:
            flash('Invalid date format')
            return render_template('prayers/create.html', form=form)
    return render_template('prayers/create.html', form=form)

@app.route('/prayers')
def view_prayers():
    prayers = PrayerSession.query.filter(
        PrayerSession.date_time >= datetime.utcnow()
    ).order_by(PrayerSession.date_time).all()
    return render_template('prayers/list.html', prayers=prayers)

@app.route('/prayers/<int:id>')
def prayer_detail(id):
    session = PrayerSession.query.get_or_404(id)
    return render_template('prayers/view.html', session=session)

@app.route('/prayers/<int:id>/join', methods=['POST'])
@login_required
def join_prayer(id):
    session = PrayerSession.query.get_or_404(id)
    if session.capacity and len(session.attendees) >= session.capacity:
        flash('Session is full!')
        return redirect(url_for('prayer_detail', id=id))

    attendee = SessionAttendee(user_id=current_user.id, session_id=id)
    db.session.add(attendee)
    db.session.commit()
    flash('Joined prayer session successfully!')
    return redirect(url_for('prayer_detail', id=id))