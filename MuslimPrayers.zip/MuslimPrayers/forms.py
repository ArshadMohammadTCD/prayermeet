from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SelectField, TextAreaField, FloatField, IntegerField
from wtforms.validators import DataRequired, Email, Length, Optional

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])

class RegisterForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=64)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])

class PrayerSessionForm(FlaskForm):
    prayer_type = SelectField('Prayer', validators=[DataRequired()],
                            choices=[('Fajr', 'Fajr'), ('Zuhr', 'Zuhr'), 
                                   ('Asr', 'Asr'), ('Maghrib', 'Maghrib'),
                                   ('Isha', 'Isha')])
    date_time = StringField('Date and Time', validators=[DataRequired()])
    location_name = StringField('Location Name', validators=[DataRequired()])
    latitude = FloatField('Latitude', validators=[DataRequired()])
    longitude = FloatField('Longitude', validators=[DataRequired()])
    capacity = IntegerField('Capacity', validators=[Optional()])
    notes = TextAreaField('Notes', validators=[Optional(), Length(max=500)])