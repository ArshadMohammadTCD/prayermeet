document.addEventListener('DOMContentLoaded', function() {
    // Dark mode toggle
    const darkModeToggle = document.getElementById('darkModeToggle');
    if (darkModeToggle) {
        darkModeToggle.addEventListener('change', function() {
            document.body.classList.toggle('dark-mode');
            updateMapMode(document.body.classList.contains('dark-mode'));
        });
    }

    // DateTime picker initialization
    const dateTimeInputs = document.querySelectorAll('input[type="datetime-local"]');
    dateTimeInputs.forEach(input => {
        const now = new Date();
        input.min = now.toISOString().slice(0, 16);
    });

    // Prayer time calculation
    function calculatePrayerTimes(lat, lng) {
        // This is a simplified calculation
        const date = new Date();
        const times = {
            fajr: '05:00',
            zuhr: '12:30',
            asr: '15:45',
            maghrib: '18:30',
            isha: '20:00'
        };
        return times;
    }

    // Update prayer times if location is available
    if ("geolocation" in navigator) {
        navigator.geolocation.getCurrentPosition(function(position) {
            const times = calculatePrayerTimes(
                position.coords.latitude,
                position.coords.longitude
            );
            updatePrayerTimes(times);
        });
    }
});

function updatePrayerTimes(times) {
    Object.entries(times).forEach(([prayer, time]) => {
        const element = document.getElementById(`${prayer}-time`);
        if (element) {
            element.textContent = time;
        }
    });
}
