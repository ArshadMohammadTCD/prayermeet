let map;
let markers = [];
let currentMarker = null;

function initMap(centerLat = 53.3498, centerLng = -6.2603) { // Dublin coordinates
    // Try to get user's location first
    if ("geolocation" in navigator) {
        navigator.geolocation.getCurrentPosition(function(position) {
            centerLat = position.coords.latitude;
            centerLng = position.coords.longitude;
            initializeMap(centerLat, centerLng);
        }, function(error) {
            // If geolocation fails, use Dublin as default
            console.log('Geolocation failed, using Dublin as default:', error);
            initializeMap(centerLat, centerLng);
        });
    } else {
        // If geolocation not supported, use Dublin as default
        console.log('Geolocation not supported, using Dublin as default');
        initializeMap(centerLat, centerLng);
    }
}

function initializeMap(lat, lng) {
    console.log('Initializing map at:', lat, lng);
    map = L.map('map').setView([lat, lng], 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    // Add click handler for creating new prayer sessions
    map.on('click', function(e) {
        const lat = e.latlng.lat;
        const lng = e.latlng.lng;

        // Update hidden form fields if they exist
        if (document.getElementById('latitude') && document.getElementById('longitude')) {
            document.getElementById('latitude').value = lat;
            document.getElementById('longitude').value = lng;

            // Remove previous marker if it exists
            if (currentMarker) {
                map.removeLayer(currentMarker);
            }

            // Add new marker
            currentMarker = L.marker([lat, lng]).addTo(map);

            // Reverse geocode to get address
            fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`)
                .then(response => response.json())
                .then(data => {
                    const address = data.display_name;
                    document.getElementById('location_name').value = address;
                    const locationInfo = `Selected Location: ${address}`;
                    document.getElementById('selected-location').textContent = locationInfo;
                    currentMarker.bindPopup(locationInfo).openPopup();
                })
                .catch(error => {
                    console.error('Error getting address:', error);
                    document.getElementById('selected-location').textContent = 
                        `Selected Location: ${lat.toFixed(6)}, ${lng.toFixed(6)}`;
                });

            // Dispatch custom event for location selection
            window.dispatchEvent(new CustomEvent('locationSelected', {
                detail: { lat, lng }
            }));
        }
    });
}

function addPrayerMarker(lat, lng, title, prayerType, sessionId, dateTime, attendees = []) {
    console.log('Adding prayer marker:', { lat, lng, title, prayerType, sessionId, dateTime, attendees });

    const marker = L.marker([lat, lng])
        .bindPopup(`
            <div class="prayer-marker">
                <strong>${title}</strong>
                <span class="badge bg-primary">${prayerType}</span>
                <p class="mb-2">
                    <i class="fas fa-calendar"></i> ${dateTime}
                </p>
                <div class="mt-2">
                    <strong>
                        <i class="fas fa-users"></i> 
                        Attendees (${attendees.length})
                    </strong>
                    <ul class="list-unstyled">
                        ${attendees.map(attendee => `
                            <li>
                                <i class="fas fa-user-circle"></i> ${attendee}
                            </li>
                        `).join('')}
                    </ul>
                </div>
                <a href="/prayers/${sessionId}" class="btn btn-sm btn-primary mt-2 w-100">
                    <i class="fas fa-info-circle"></i> View Details
                </a>
            </div>
        `, {
            maxWidth: 300,
            className: 'prayer-popup'
        })
        .addTo(map);

    markers.push(marker);
    console.log('Marker added successfully');
}

function clearMarkers() {
    markers.forEach(marker => map.removeLayer(marker));
    markers = [];
}

// Handle dark/light mode for map
function updateMapMode(isDark) {
    if (!map) return;

    if (isDark) {
        map.getContainer().classList.add('dark-map');
    } else {
        map.getContainer().classList.remove('dark-map');
    }
}